<?php
namespace App\Controller;

use App\Controller\AppController;

class BookController extends AppController {

    //Constructor
    public function initialize(){
        parent::initialize();
        $this->viewBuilder()->setLayout('booklayout');
        $this->loadModel('Books');
    }

    //To display Book List
    public function index(){
        $this->set("title", "Book List");

        $books = $this->Books->find('all', [
            'order' => ['id'=>'desc']
        ]);
        $this->set('books', $books);
    }

    public function create(){
        $this->set("title", "Book Create");
    }

    //To save the Books Added to DB
    public function save(){
        $this->autoRender = false;
        //print_r($this->request->data); die;

        //Validation Logic
        $book = $this->Books->newEntity($this->request->data);
        $validation = $book->errors();
        if(!empty($validation)){
            //print_r($this->request->data); die;
            //Errors
            $this->Flash->set($validation, [
                'element'=>'book_error'
            ]);
        } else {
            //Success No Errors, then Save to DB
            //print_r($this->request->data); die;
            $form_data = $this->request->data;
            $uploaded_path = '/img/uploads';
            $tmp_name = $this->request->data['file']['tmp_name'];
            //Image is valid or not.
            $validImage = getimagesize($tmp_name);
            if($validImage === FALSE){
                //Not able to read image file.
                $this->Flash->set('Image file is not valid.', [
                    'element'=>'book_success'
                ]);
            }
            else{

                $image_name = $this->request->data['file']['name'];

            if(move_uploaded_file($tmp_name, WWW_ROOT.$uploaded_path.'/'.$image_name)){

                $book->name = $form_data['name'];
                $book->author = $form_data['author'];
                $book->email = $form_data['email'];
                $book->description = $form_data['description'];
                $book->img = $uploaded_path.'/'.$image_name;

                $this->Books->save($book);
                $this->Flash->set('Book has been addeded successfully', [
                    'element'=>'book_success'
                ]);

            }
            else {
                $this->Flash->set('Image has been not been uploaded successfully', [
                    'element'=>'book_error'
                ]);
            }

            }
        }

        //Redirect to create page
        $this->redirect(['action'=>'create']);
    }

    //To view Edit page
    public function edit($id){
        $book = $this->Books->get($id);
        $this->set('book', $book);
        $this->set("title", "Book Edit");
    }

    //To update the Books edited to DB
    public function update(){
        $this->autoRender = false;
        $formdata = $this->request->data;
        $book = $this->Books->get($formdata['bookID']);
        $book->name = $formdata['name'];
        $book->author = $formdata['author'];
        $book->email = $formdata['email'];
        $book->description = $formdata['description'];

        $this->Books->save($book);
        $this->Flash->set('Book has been Updated', [
            'element' => 'book_success'
        ]);

        //Redirect to edit page
        $this->redirect(['action'=>'edit/'.$formdata['bookID']]);
    }

    //To delete a Book from DB
    public function delete($id){
        $this->autoRender = false;
        $book = $this->Books->get($id);
        $this->Books->delete($book);
        $this->Flash->set('Book has been deleted', [
            'element' => 'book_success'
        ]);

        //Redirect to index page
        $this->redirect(['action'=>'index']);
    }

}
