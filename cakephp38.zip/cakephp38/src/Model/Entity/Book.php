<?php

namespace App\Model\Entity;

use Cake\ORM\Entity;

class Book extends Entity {

    /*Accessors
    protected function _getName($name){ //name
        return strtoupper($name);
    }
    
    protected function _getAuthor($value){ //author
        return $value." - Lalit";
    }

    protected function _getNameEmail(){ //name_email
        return $this->_properties['name'].", ".$this->_properties['email'];
    }*/

    /* Mutators 
    protected function _setName($value){
        return strtoupper($value);
    }*/

}