<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class BooksTable extends Table {

    public function validationDefault(Validator $validator){

        $validator
        ->requirePresence([
            'name'=> [
                'mode'=>'create',
                'message'=>'Book Name Required'
            ],
            'author'=> [
                'mode'=>'create',
                'messsage'>'Author Name Required'
            ],
            'email'=> [
                'mode'=>'create',
                'messsage'>'Email Address Required'
            ]
        ])
        ->add('name', [
            'length'=>[
                'rule'=>['minLength',6],
                'message'=>'Book Name should be min 6 Letters'
            ]
        ])
        ->add('email', [
            'valid_email'=>[
                'rule'=>['email'],
                'message'=>'Invalid Email Address'
            ]
        ])
        ->add('email', [
            'unique_email'=>[
                'rule'=>['validateUnique'],
                'provider'=>'table',
                'message'=>'Email Already Exists'
            ]
        ]);        

        return $validator;
    }
    
}