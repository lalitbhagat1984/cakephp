<?php

namespace App\view\Helper;

use Cake\View\Helper;

class MathHelper extends Helper
{
	
	public function square($number1)
	{
		// Logic to create specially formatted link goes here...
		return $number1 * $number1;
	}

	public function stringLength($string)
	{
		return strlen($string);
	}

}