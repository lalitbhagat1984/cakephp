<?php

namespace App\Model\Table;

use Cake\ORM\Table;


class FruitsTable extends Table
{

	

}

?>