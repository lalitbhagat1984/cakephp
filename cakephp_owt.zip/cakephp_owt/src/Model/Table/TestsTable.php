<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class TestsTable extends Table
{

	public function validationDefault( Validator $validator ){

		//Rules
		$validator->requirePresence("email", "create", "Email Required.")
		->add("email", [
			"unique" => [
				"rule" => "validateUnique",
				"provider" => "table",
				"message" => "Email should be Unique"
			]
		])
		->requirePresence("password", "create", "Password Required.")
		->requirePresence("confirm_password", "create", "Confirm Password Required.")
		->add("confirm_password", [
			"password_mismatch" => [
				"rule" => ["compareWith", "password"],
				"message" => "Passwords Not Matched."
			]
		])
		;

		return $validator;

	}

}

?>