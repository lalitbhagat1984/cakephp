<?php

namespace App\Controller;

use App\Controller\AppController;


class OnlineController extends AppController
{
	
	function onlineChannel()
	{
		
	}

	public function call(){
		echo "OnlineController with call function";
	}

	public function myform2(){

		$this->viewBuilder()->layout(false);

		if($this->request->is('post')){

			//collect data from form
			$data = $this->request->data;
			print_r($data);

		}
		
	}

}