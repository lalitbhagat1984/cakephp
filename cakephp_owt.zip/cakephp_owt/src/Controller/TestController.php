<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;
//use Cake\Validation\Validator;

class TestController extends AppController
{
	public $url;
	private $connection;
	private $table;

	public function initialize(){
		parent::initialize();

		//To set our layout.
		$this->viewBuilder()->layout('owtlayout');

		$this->url = Router::url('/', true);

		//Connection Manager Reference (Database Instance)
		$this->connection = ConnectionManager::get('default');

		//Table Registry (Table Instance)
		$this->table = TableRegistry::get("employees");

		//Load Modal
		$this->loadModel("Fruits");

	}

	public function testvalidate(){

		$this->autoRender = false;

		$validator = new Validator;

		//$this->request->data();

		$req_data = array(
			'name' => 'Nicole',
			'email' => 'oops@gmail.com',
			'age' => 18,
			'url' => 'nicole' 
		);

		//Rules
		$validator
		->requirePresence("name", "create", "Name Field Required.")
		->add("name", "length", [
				"rule" => ["minLength", 6],
				"message" => "Name of Min Length of 6 Required."
		])
		->requirePresence("email", "create", "Email Field Required.")
		->add("email", [
			"email" => [
				"rule" => ["email"],
				"message" => "Invalid Email"
			]
		])
		->requirePresence("age", "create", "Age Field Required.")
		->numeric("age", "Age Field Should be Numeric.", "create")
		/*->add("name", [
			"length" => [
				"rule" => ["minLength", 6],
				"message" => "Min Length of 6 Required."
			]
		])*/
		->requirePresence("url", "create", "Url Field Required.")
		->url("url", "Proper Url Required.", "create")
		//->allowEmpty("url");
		->notEmpty("url", "Url Field Needed.", "create");

		$validation = $validator->errors($req_data);
		if (!empty($validation)) {
			//errors
			print_r($validation);
			echo $validation['url']['url'];
		} else {
			//success
			echo "Passed Successfully";
		}
		

	}

	public function validatedatabymodel(){
		$this->autoRender = false;

		$req_data = [
			"email" => "lalit@gmail.com",
			"password" => "lalit",
			"confirm_password" => "lalit"
		];

		$this->loadModel("Tests");
		$validation = $this->Tests->newEntity($req_data);
		$validationErrors = $validation->errors();

		if (!empty($validationErrors)) {
			//errors
			print_r($validationErrors);
		} else {
			//success.
			echo "Successfully Passed";
		}
		
	}

	public function insertmodel(){

		$this->autoRender = false;

		//Create New Entity
		/*$fruitsObj = $this->Fruits->newEntity();

		$fruitsObj->name = "Apple";
		$fruitsObj->description = "An Apple a day keeps doctor away.";

		$this->Fruits->save($fruitsObj);*/

		//Using Query Builder
		$fruitsObjQuery = $this->Fruits->query();
		$fruitsObjQuery->insert(["name", "description"])->values([
			"name"=>"Banana",
			"description" => "Banana is good for diet."])->execute();

	}

	public function getdatamodel(){

		//$this->autoRender = false;

		$data = $this->Fruits->find()->toArray();
		/*$data = $this->Fruits->find('all', [
			"conditions" => [ "id" => 2 ]
		])->toArray();*/
		/*$data = $this->Fruits->find('all', [
			"order" => [ "id" => "desc" ]
		])->toArray();*/
		//print_r($data);
		/*foreach ($data as $key => $value) {
			echo $value->name." : ".$value->description." <br/>";
		}*/

		$this->set("data", $data);

	}

	public function updatedatamodel(){

		$this->autoRender = false;

		/*$data = $this->Fruits->get(2);
		$data->name = "Orange";
		$data->description = "The Oranges in Nagpur city are best in the World";
		if($this->Fruits->save($data)){
			echo "Row Updated";
		}
		else{
			echo "Failed to Update";
		}*/

		//Using Query
		$data = $this->Fruits->query();
		$data->update()->set([
			"name" => "Grapes",
			"description" => "Green grapes are good for health."
		])->where([
			"id" => 2
		])->execute();

	}

	public function deletemodeldata(){

		$this->autoRender = false;

		/*$data = $this->Fruits->get(1);
		if($this->Fruits->delete($data)){
			echo "Record Deleted";
		}else{
			echo "Failed to delete";
		}*/

		//Using Query
		$data = $this->Fruits->query();
		$data->delete()->where([
			"id" => 2
		])->execute();

	}

	public function tabledata(){

		$this->autoRender = false;

		$tableIns = $this->table->newEntity();

		//Insert Data : Method 1
		/*$tableIns->name = "Ron";
		$tableIns->email = "ronbaba@gmail.com";
		$tableIns->phone = "9975848899";
		$this->table->save($tableIns);*/

		//Insert Data : Method 2
		$tableIns['name'] = "Rocco";
		$tableIns['email'] = "roccobaba@gmail.com";
		$tableIns['phone'] = "9975696969";
		$this->table->save($tableIns);
		echo $tableIns->id;
	}

	public function selecttable(){

		$this->autoRender = false;

		//$datas = $this->table->find('all')->toArray();
		//$datas = $this->table->find('all');
		/*$datas = $this->table->find('all',[
			"conditions" => ["id" => 3]
		]);*/
		/*$datas = $this->table->find('all',[
			"conditions" => ["id" => 3]
		])->toList();*/
		//$datas = $this->table->find('all')->where(["id" => 4])->toList();
		//$datas = $this->table->find('all')->order(["id" => "desc"])->toList();
		/*$datas = $this->table->find('all',[
			"conditions" => ["id" => 4],
			"order" => ["id" => "desc"],
			"limit" => 4
		])->toList();*/
		$datas = $this->table->find('all')->select(["name", "email"])->order(["id" => "desc"])->limit(2)->toList();
		print_r($datas);

		foreach ($datas as $key => $value) {
			echo $value->name." : ".$value->email."<br/>";
		}
	}

	public function insertdata(){
		
		//Insert Method
		/*$this->connection->insert("employees", [
			"name" => "Cakephp Tuts",
			"email" => "cakephp@gmail.com",
			"phone" => "9860848899"
		]);*/

		/*$this->connection->insert("employees", [
			"name" => "Jeniffer Bhagat",
			"email" => "jennibhagat@gmail.com",
			"phone" => "98609192939"
		]);*/


		//Update Method
		/*$this->connection->update("employees", [
			"name" => "Neha Bhagat",
			"email" => "nehabhagat@gmail.com",
			"phone" => "9860696969" //Set Values
		], [
			"id" => 1 //Where Condition
		]);*/


		//Delete Method
		/*$this->connection->delete("employees", [
			"id" => 2 //Delete Condition
		]);*/

	}

	public function updatedata(){

		$this->autoRender = false;

		$data = $this->table->get(5);
		//print_r($data);

		$data->name = "Jeniffer Aniston";
		$data->email = "jennifer143@gmail.com";
		$data->phone = "9860699669";

		//echo $this->table->save($data);

		if($this->table->save($data)) {
			echo "Record Updated";
		}else{
			echo "Update Failed";
		}
	}

	public function deletedata(){

		$this->autoRender = false;

		$data = $this->table->get(7);
		//echo $this->table->delete($data);

		if($this->table->delete($data)){
			echo "Record Deleted";
		}else{
			echo "Deletion Failed";
		}
	}

	public function selectdata(){
		$this->autoRender = false;

		//As Indexed Array
		//$datas = $this->connection->execute("SELECT * FROM employees")->fetchAll();
		//print_r($datas);

		//As an Associtive Array
		/*$datas = $this->connection->execute("SELECT * FROM employees")->fetchAll("assoc");
		print_r($datas);
		echo "<br/><br/>";*/

		/*foreach ($datas as $data) {
			echo $data['name']." : ".$data['email']." : ".$data['phone']." <br/> ";
		}*/

		//To Access only one Record: Method 1 using limit 1
		/*$datas = $this->connection->execute("SELECT * FROM employees limit 1")->fetchAll("assoc");
		print_r($datas);*/

		//To Access only one Record: Method 2 using fetch instead of fetchAll
		/*$datas = $this->connection->execute("SELECT * FROM employees")->fetch("assoc");
		print_r($datas);*/

		//To use condtions
		/*$datas = $this->connection->execute("SELECT * FROM employees where id = 3")->fetchAll("assoc");
		print_r($datas);*/

		//To use condtions & placeholder
		/*$datas = $this->connection->execute("SELECT * FROM employees where id = :id", ["id" => 1])->fetchAll("assoc");
		print_r($datas);*/

		//To use query builder
		/*$datas = $this->connection->newQuery()->select("*")->from('employees')->where(["id" => 4])->execute()->fetchAll("assoc");
		print_r($datas);*/

		//To use query builder for orderby
		$datas = $this->connection->newQuery()->select("*")->from('employees')->order(["id" => "desc"])->execute()->fetchAll("assoc");
		print_r($datas);

	}
	
	function index()
	{
		//print_r($this->url);die;
		//echo $this->url."webroot/img/cake-logo.png"; die;

		//$this->autoRender = false;
		//echo "Index function in TestController with autoRender false";

		//Sending values to template file individually.
		$this->set("name","Lalit"); //$name
		$this->set("channel", "Cakephp Tutorials"); //$channel

		$fullName = "Lalit Bhagat";

		//Sending values to template file as an array.
		$channelProfile = array("Name" => "Cakephp Tuts", "Author" => "Lalit", "Social" => "Youtube");
		//Method One: Using basic set function
		$this->set("data", $channelProfile);
		//Method Two: Using set function along with php compact function
		$this->set(compact("channelProfile", "fullName"));

		//Set Title
		$this->set("title", "CakePHP Tutorials");

	}

	public function showmessage(){

		//Form Submission Code.

		//Flash Message
		$this->Flash->set('Form Submitted Successfully.', [
			'element' => 'greatSuccess'
		]);
	}

	function owt()
	{
		//$this->autoRender = false;
		//echo "<h1>OWT function in TestController with autoRender false</h1>";

		$this->set("message", "Welcome to TestController OWT Method");
	}

	public function myformsubmit(){
		$this->viewBuilder()->layout(false);
		
		if($this->request->is('post')){

			//collect data from form
			$data = $this->request->data;
			print_r($data);

		}
	}

	public function myform(){
		$this->viewBuilder()->layout(false);

		//Form Submission
		/*if($this->request->is('post')){

			//collect data from form
			$data = $this->request->data;
			print_r($data);

		}*/

	}

	public function customfunctions(){
		
	}

}